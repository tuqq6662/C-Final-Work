﻿// ScannerB/ScannerB.cs
using System;
using System.IO;
using System.IO.Pipes;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace scannerB
{
    class Scanner
    {
        private readonly string directoryPath;
        private readonly string pipeName;
        private readonly int coreNumber;
        private readonly Dictionary<string, Dictionary<string, int>> wordIndex = new Dictionary<string, Dictionary<string, int>>();
        private readonly object lockObject = new object();

        public Scanner(string directoryPath, string pipeName, int coreNumber)
        {
            this.directoryPath = directoryPath;
            this.pipeName = pipeName;
            this.coreNumber = coreNumber;
        }

        public void Start()
        {
            // Set CPU core affinity (core 2 for ScannerB)
            Process.GetCurrentProcess().ProcessorAffinity = (IntPtr)(1 << coreNumber);

            // Start threads for reading files and sending data
            var readTask = Task.Run(() => ReadFiles());
            var sendTask = Task.Run(() => SendData());

            Task.WaitAll(readTask, sendTask);
        }

        private void ReadFiles()
        {
            try
            {
                foreach (var file in Directory.GetFiles(directoryPath, "*.txt"))
                {
                    var fileName = Path.GetFileName(file);
                    var wordCounts = new Dictionary<string, int>();

                    string[] words = File.ReadAllText(file)
                        .Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(w => w.ToLower().Trim())
                        .Where(w => !string.IsNullOrEmpty(w))
                        .ToArray();

                    foreach (var word in words)
                    {
                        wordCounts[word] = wordCounts.GetValueOrDefault(word, 0) + 1;
                    }

                    lock (lockObject)
                    {
                        wordIndex[fileName] = wordCounts;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading files: {ex.Message}");
            }
        }

        private void SendData()
        {
            try
            {
                using (var pipeClient = new NamedPipeClientStream(".", pipeName, PipeDirection.Out))
                {
                    bool connected = false;
                    for (int i = 0; i < 3 && !connected; i++) // Попробовать 3 раза
                    {
                        try
                        {
                            pipeClient.Connect(5000);
                            connected = true;
                        }
                        catch (TimeoutException)
                        {
                            Console.WriteLine($"Retry {i + 1}/3 to connect to pipe {pipeName}...");
                            if (i == 2) throw;
                        }
                    }
                    using (var writer = new StreamWriter(pipeClient) { AutoFlush = true })
                    {
                        while (true)
                        {
                            lock (lockObject)
                            {
                                foreach (var fileEntry in wordIndex)
                                {
                                    foreach (var wordEntry in fileEntry.Value)
                                    {
                                        string message = $"{fileEntry.Key}:{wordEntry.Key}:{wordEntry.Value}";
                                        writer.WriteLine(message);
                                    }
                                }
                            }
                            Thread.Sleep(1000);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending data: {ex.Message}");
                Console.ReadLine(); // Оставить консоль открытой для чтения ошибки
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                if (args.Length != 2)
                {
                    Console.WriteLine("Usage: ScannerB.exe <directory_path> <pipe_name>");
                    return;
                }

                string directoryPath = args[0];
                string pipeName = args[1];
                int coreNumber = 2; // Fixed core for ScannerB

                var scanner = new Scanner(directoryPath, pipeName, coreNumber);
                scanner.Start();
            }
        }
    }
}