﻿using System;
using System.IO.Pipes;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Master
{
    class Master
    {
        private readonly string[] pipeNames;
        private readonly Dictionary<string, Dictionary<string, int>> aggregatedIndex = new Dictionary<string, Dictionary<string, int>>();
        private readonly object lockObject = new object();

        public Master(string[] pipeNames)
        {
            this.pipeNames = pipeNames;
        }

        public void Start()
        {
            // Set CPU core affinity to core 0
            Process.GetCurrentProcess().ProcessorAffinity = (IntPtr)(1 << 0);

            // Start threads for each pipe and display
            var tasks = new Task[pipeNames.Length + 1];
            for (int i = 0; i < pipeNames.Length; i++)
            {
                int pipeIndex = i;
                tasks[i] = Task.Run(() => HandlePipe(pipeNames[pipeIndex]));
            }
            tasks[pipeNames.Length] = Task.Run(() => DisplayResults());

            Task.WaitAll(tasks);
        }

        private void HandlePipe(string pipeName)
        {
            try
            {
                using (var pipeServer = new NamedPipeServerStream(pipeName, PipeDirection.In))
                {
                    pipeServer.WaitForConnection();
                    using (var reader = new StreamReader(pipeServer))
                    {
                        while (true)
                        {
                            string line = reader.ReadLine();
                            if (line == null) break;

                            var parts = line.Split(':');
                            if (parts.Length == 3)
                            {
                                string fileName = parts[0];
                                string word = parts[1];
                                int count = int.Parse(parts[2]);

                                lock (lockObject)
                                {
                                    if (!aggregatedIndex.ContainsKey(fileName))
                                        aggregatedIndex[fileName] = new Dictionary<string, int>();

                                    aggregatedIndex[fileName][word] = count;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error handling pipe {pipeName}: {ex.Message}");
            }
        }

        private void DisplayResults()
        {
            while (true)
            {
                lock (lockObject)
                {
                    Console.Clear();
                    Console.WriteLine("Aggregated Word Index (Updated: {0}):", DateTime.Now.ToString("HH:mm:ss"));
                    foreach (var fileEntry in aggregatedIndex.OrderBy(x => x.Key))
                    {
                        foreach (var wordEntry in fileEntry.Value.OrderBy(x => x.Key))
                        {
                            Console.WriteLine($"{fileEntry.Key}:{wordEntry.Key}:{wordEntry.Value}");
                        }
                    }
                }
                Thread.Sleep(2000); // Refresh display every 2 seconds
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Usage: Master.exe <pipe_name1> <pipe_name2>");
                return;
            }

            var master = new Master(args);
            master.Start();
        }
    }
}