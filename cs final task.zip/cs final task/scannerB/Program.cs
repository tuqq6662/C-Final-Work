﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ScannerB
{
    class Scanner
    {
        private readonly string controlPipeName = "control2";
        private readonly string dataPipeName = "agent2";
        private readonly int coreNumber = 1; // Core 1 for ScannerB
        private readonly Dictionary<string, Dictionary<string, int>> wordIndex = new();
        private readonly object lockObject = new();

        public async Task Start()
        {
            // Set CPU core affinity to core 1
            Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(2); // Core 1

            // Get folder path from Master
            string directoryPath = await GetFolderPath();
            if (string.IsNullOrEmpty(directoryPath))
            {
                Console.WriteLine("ScannerB: No folder path received. Exiting.");
                return;
            }

            // Start tasks for reading files and sending data
            var readTask = Task.Run(() => ReadFiles(directoryPath));
            var sendTask = Task.Run(() => SendData());

            await Task.WhenAll(readTask, sendTask);
        }

        private async Task<string> GetFolderPath()
        {
            try
            {
                using (var pipeClient = new NamedPipeClientStream(".", controlPipeName, PipeDirection.In))
                {
                    Console.WriteLine($"ScannerB: Connecting to control pipe {controlPipeName}...");
                    pipeClient.Connect(10000); // Wait up to 10 seconds
                    using (var reader = new StreamReader(pipeClient))
                    {
                        string folderPath = await reader.ReadLineAsync();
                        Console.WriteLine($"ScannerB: Received folder path: {folderPath}");
                        return folderPath;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerB Control Pipe Error: {ex.Message}");
                return null;
            }
        }

        private void ReadFiles(string directoryPath)
        {
            try
            {
                if (!Directory.Exists(directoryPath))
                {
                    Console.WriteLine($"ScannerB: Directory {directoryPath} does not exist.");
                    return;
                }

                foreach (var file in Directory.GetFiles(directoryPath, "*.txt"))
                {
                    var fileName = Path.GetFileName(file);
                    var wordCounts = new Dictionary<string, int>();

                    string[] words = File.ReadAllText(file)
                        .Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(w => w.ToLower().Trim(new[] { '.', ',', '!', '?' }))
                        .Where(w => !string.IsNullOrEmpty(w))
                        .ToArray();

                    foreach (var word in words)
                    {
                        wordCounts[word] = wordCounts.GetValueOrDefault(word, 0) + 1;
                    }

                    lock (lockObject)
                    {
                        wordIndex[fileName] = wordCounts;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerB: Error reading files: {ex.Message}");
            }
        }

        private void SendData()
        {
            try
            {
                using (var pipeClient = new NamedPipeClientStream(".", dataPipeName, PipeDirection.Out))
                {
                    bool connected = false;
                    for (int i = 0; i < 3 && !connected; i++)
                    {
                        try
                        {
                            pipeClient.Connect(5000);
                            connected = true;
                        }
                        catch (TimeoutException)
                        {
                            Console.WriteLine($"ScannerB: Retry {i + 1}/3 to connect to pipe {dataPipeName}...");
                            if (i == 2) throw;
                        }
                    }
                    using (var writer = new StreamWriter(pipeClient) { AutoFlush = true })
                    {
                        lock (lockObject)
                        {
                            foreach (var fileEntry in wordIndex)
                            {
                                foreach (var wordEntry in fileEntry.Value)
                                {
                                    string message = $"{fileEntry.Key}:{wordEntry.Key}:{wordEntry.Value}";
                                    writer.WriteLine(message);
                                    Console.WriteLine($"ScannerB: Sent {message}");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerB: Error sending data: {ex.Message}");
                Console.ReadLine(); // Keep console open to read error
            }
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            var scanner = new Scanner();
            await scanner.Start();
        }
    }
}