﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ScannerA
{
    class Scanner
    {
        private readonly string controlPipeName = "control1";
        private readonly string dataPipeName = "agent1";
        private readonly int coreNumber = 0; // Core 0 for ScannerA
        private readonly Dictionary<string, Dictionary<string, int>> wordIndex = new();
        private readonly object lockObject = new();

        public async Task Start()
        {
            // Set CPU core affinity to core 0
            Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(1); // Core 0

            // Create cancellation token for 60 seconds timeout
            using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(60)))
            {
                CancellationToken token = cts.Token;
                try
                {
                    // Get folder path from Master
                    string directoryPath = await GetFolderPath(token);
                    if (string.IsNullOrEmpty(directoryPath))
                    {
                        Console.WriteLine("ScannerA: Путь к папке не получен. Завершение работы.");
                        return;
                    }

                    // Start tasks for reading files and sending data
                    var readTask = Task.Run(() => ReadFiles(directoryPath, token), token);
                    await readTask; // Wait for reading to complete
                    var sendTask = Task.Run(() => SendData(token), token);

                    await sendTask; // Wait for sending to complete
                }
                catch (OperationCanceledException)
                {
                    Console.WriteLine("ScannerA: Завершение работы по таймеру (60 секунд).");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"ScannerA: Ошибка: {ex.Message}");
                    Console.ReadLine(); // Keep console open for error reading
                }
            }
        }

        private async Task<string> GetFolderPath(CancellationToken token)
        {
            try
            {
                using (var pipeClient = new NamedPipeClientStream(".", controlPipeName, PipeDirection.In))
                {
                    Console.WriteLine($"ScannerA: Connecting to control pipe {controlPipeName}...");
                    await pipeClient.ConnectAsync(10000, token); // Wait up to 10 seconds
                    using (var reader = new StreamReader(pipeClient))
                    {
                        string folderPath = await reader.ReadLineAsync();
                        Console.WriteLine($"ScannerA: Received folder path: {folderPath}");
                        return folderPath;
                    }
                }
            }
            catch (OperationCanceledException)
            {
                throw; // Propagate cancellation
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerA Control Pipe Error: {ex.Message}");
                return null;
            }
        }

        private void ReadFiles(string directoryPath, CancellationToken token)
        {
            try
            {
                token.ThrowIfCancellationRequested();
                if (!Directory.Exists(directoryPath))
                {
                    Console.WriteLine($"ScannerA: Папка {directoryPath} не существует.");
                    return;
                }

                foreach (var file in Directory.GetFiles(directoryPath, "*.txt"))
                {
                    token.ThrowIfCancellationRequested();
                    var fileName = Path.GetFileName(file);
                    var wordCounts = new Dictionary<string, int>();

                    string[] words = File.ReadAllText(file)
                        .Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(w => w.ToLower().Trim(new[] { '.', ',', '!', '?' }))
                        .Where(w => !string.IsNullOrEmpty(w))
                        .ToArray();

                    foreach (var word in words)
                    {
                        wordCounts[word] = wordCounts.GetValueOrDefault(word, 0) + 1;
                    }

                    lock (lockObject)
                    {
                        wordIndex[fileName] = wordCounts;
                    }
                }
            }
            catch (OperationCanceledException)
            {
                throw; // Propagate cancellation
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerA: Ошибка чтения файлов: {ex.Message}");
            }
        }

        private void SendData(CancellationToken token)
        {
            try
            {
                token.ThrowIfCancellationRequested();
                using (var pipeClient = new NamedPipeClientStream(".", dataPipeName, PipeDirection.Out))
                {
                    bool connected = false;
                    for (int i = 0; i < 3 && !connected; i++)
                    {
                        try
                        {
                            pipeClient.Connect(5000);
                            connected = true;
                        }
                        catch (TimeoutException)
                        {
                            Console.WriteLine($"ScannerA: Повторная попытка {i + 1}/3 подключения к каналу {dataPipeName}...");
                            if (i == 2) throw;
                        }
                    }
                    using (var writer = new StreamWriter(pipeClient) { AutoFlush = true })
                    {
                        lock (lockObject)
                        {
                            foreach (var fileEntry in wordIndex)
                            {
                                token.ThrowIfCancellationRequested();
                                foreach (var wordEntry in fileEntry.Value)
                                {
                                    string message = $"{fileEntry.Key}:{wordEntry.Key}:{wordEntry.Value}";
                                    writer.WriteLine(message);
                                    Console.WriteLine($"ScannerA: Отправлено: {message}");
                                }
                            }
                        }
                    }
                }
            }
            catch (OperationCanceledException)
            {
                throw; // Propagate cancellation
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerA: Ошибка отправки данных: {ex.Message}");
            }
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            var scanner = new Scanner();
            await scanner.Start();
        }
    }
}