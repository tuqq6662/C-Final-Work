﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ScannerA
{
    class Scanner
    {
        private readonly string controlPipeName = "control1";
        private readonly string dataPipeName = "agent1";
        private readonly int coreNumber = 0; // Core 0 for ScannerA
        private readonly Dictionary<string, Dictionary<string, int>> wordIndex = new();
        private readonly object lockObject = new();

        // Starts the ScannerA process
        public async Task Start()
        {
            // Set CPU core affinity to core 0
            Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(1); // Core 0

            try
            {
                // Get paths from Master
                Console.WriteLine("ScannerA: Waiting for paths...");
                string paths = await GetPaths();
                if (string.IsNullOrEmpty(paths))
                {
                    Console.WriteLine("ScannerA: No paths received. Exiting.");
                    Console.WriteLine("Press Enter to exit...");
                    Console.ReadLine();
                    return;
                }
                Console.WriteLine($"ScannerA: Received paths: {paths}");

                // Start tasks for reading files and sending data
                var readTask = Task.Run(() => ReadFiles(paths));
                await readTask; // Wait for reading to complete
                var sendTask = Task.Run(() => SendData());

                await sendTask; // Wait for sending to complete
                Console.WriteLine("ScannerA: Processing complete. Press Enter to exit...");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerA: Error: {ex.Message}");
                Console.WriteLine("Press Enter to exit...");
                Console.ReadLine();
            }
        }

        // Retrieves paths (folder or file list) from Master via control pipe
        private async Task<string> GetPaths()
        {
            try
            {
                using (var pipeClient = new NamedPipeClientStream(".", controlPipeName, PipeDirection.In))
                {
                    Console.WriteLine($"ScannerA: Connecting to control pipe {controlPipeName}...");
                    for (int i = 0; i < 3; i++)
                    {
                        try
                        {
                            await pipeClient.ConnectAsync(5000); // 5 seconds timeout per attempt
                            Console.WriteLine($"ScannerA: Connected to {controlPipeName}");
                            break;
                        }
                        catch (TimeoutException)
                        {
                            Console.WriteLine($"ScannerA: Retry {i + 1}/3 connecting to {controlPipeName}...");
                            if (i == 2) throw new TimeoutException("Failed to connect to control pipe.");
                        }
                    }
                    using (var reader = new StreamReader(pipeClient))
                    {
                        string paths = await reader.ReadLineAsync();
                        return paths;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerA: Control pipe error: {ex.Message}");
                return null;
            }
        }

        // Reads and indexes words from files (folder or file list)
        private void ReadFiles(string paths)
        {
            try
            {
                List<string> filesToProcess;

                // Check if paths is a folder or file list
                if (Directory.Exists(paths))
                {
                    if (!Directory.Exists(paths))
                    {
                        Console.WriteLine($"ScannerA: Folder {paths} does not exist.");
                        return;
                    }
                    filesToProcess = Directory.GetFiles(paths, "*.txt").ToList();
                }
                else
                {
                    // Assume semicolon-separated file list
                    filesToProcess = paths.Split(';', StringSplitOptions.RemoveEmptyEntries)
                                         .Where(f => File.Exists(f) && Path.GetExtension(f).Equals(".txt", StringComparison.OrdinalIgnoreCase))
                                         .ToList();
                    if (!filesToProcess.Any())
                    {
                        Console.WriteLine("ScannerA: No valid .txt files in the provided list.");
                        return;
                    }
                }

                foreach (var file in filesToProcess)
                {
                    Console.WriteLine($"ScannerA: Processing file {file}...");
                    var fileName = Path.GetFileName(file);
                    var wordCounts = new Dictionary<string, int>();

                    string[] words = File.ReadAllText(file)
                        .Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(w => w.ToLower().Trim(new[] { '.', ',', '!', '?' }))
                        .Where(w => !string.IsNullOrEmpty(w))
                        .ToArray();

                    if (words.Length == 0)
                    {
                        Console.WriteLine($"ScannerA: File {fileName} is empty or contains no valid words.");
                        continue;
                    }

                    foreach (var word in words)
                    {
                        wordCounts[word] = wordCounts.GetValueOrDefault(word, 0) + 1;
                    }

                    lock (lockObject)
                    {
                        wordIndex[fileName] = wordCounts;
                    }
                }
                Console.WriteLine("ScannerA: File reading complete.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerA: Error reading files: {ex.Message}");
            }
        }

        // Sends indexed data to Master via data pipe
        private void SendData()
        {
            try
            {
                using (var pipeClient = new NamedPipeClientStream(".", dataPipeName, PipeDirection.Out))
                {
                    Console.WriteLine($"ScannerA: Connecting to data pipe {dataPipeName}...");
                    bool connected = false;
                    for (int i = 0; i < 3 && !connected; i++)
                    {
                        try
                        {
                            pipeClient.Connect(5000); // 5 seconds timeout per attempt
                            connected = true;
                            Console.WriteLine($"ScannerA: Connected to {dataPipeName}");
                        }
                        catch (TimeoutException)
                        {
                            Console.WriteLine($"ScannerA: Retry {i + 1}/3 connecting to {dataPipeName}...");
                            if (i == 2) throw new TimeoutException("Failed to connect to data pipe.");
                        }
                    }
                    using (var writer = new StreamWriter(pipeClient) { AutoFlush = true })
                    {
                        lock (lockObject)
                        {
                            if (wordIndex.Count == 0)
                            {
                                Console.WriteLine("ScannerA: No data to send (empty index).");
                            }
                            foreach (var fileEntry in wordIndex)
                            {
                                foreach (var wordEntry in fileEntry.Value)
                                {
                                    string message = $"{fileEntry.Key}:{wordEntry.Key}:{wordEntry.Value}";
                                    writer.WriteLine(message);
                                    Console.WriteLine($"ScannerA: Sent: {message}");
                                }
                            }
                        }
                    }
                }
                Console.WriteLine("ScannerA: Data sending complete.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ScannerA: Error sending data: {ex.Message}");
            }
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            var scanner = new Scanner();
            await scanner.Start();
        }
    }
}