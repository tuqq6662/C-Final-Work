﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Master
{
    class Master
    {
        private readonly string[] dataPipeNames = { "agent1", "agent2" };
        private readonly string[] controlPipeNames = { "control1", "control2" };
        private readonly Dictionary<string, Dictionary<string, int>> aggregatedIndex = new();
        private readonly object lockObject = new();

        public void Start()
        {
            // Set CPU core affinity to core 2
            Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(4); // Core 2

            // Prompt user to enter a folder path
            string folderPath = SelectFolder();
            if (string.IsNullOrEmpty(folderPath))
            {
                Console.WriteLine("Неверный путь или папка не выбрана. Завершение работы.");
                return;
            }
            Console.WriteLine($"Выбранная папка: {folderPath}");

            // Start tasks to send folder path to Scanners
            Task[] controlTasks = new Task[controlPipeNames.Length];
            for (int i = 0; i < controlPipeNames.Length; i++)
            {
                string pipeName = controlPipeNames[i];
                controlTasks[i] = Task.Run(() => SendFolderPath(folderPath, pipeName));
            }

            // Start tasks to listen for data from Scanners
            Task[] dataTasks = new Task[dataPipeNames.Length];
            for (int i = 0; i < dataPipeNames.Length; i++)
            {
                string pipeName = dataPipeNames[i];
                dataTasks[i] = Task.Run(() => HandlePipe(pipeName));
            }

            // Start task to display results
            Task displayTask = Task.Run(() => DisplayResults());

            // Wait for all tasks to complete
            Task.WaitAll(controlTasks.Concat(dataTasks).Append(displayTask).ToArray());
        }

        private string SelectFolder()
        {
            int maxAttempts = 3;
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                Console.WriteLine($"Введите полный путь к папке с .txt файлами (например, C:\\TestFiles) (попытка {attempt}/{maxAttempts}):");
                string path = Console.ReadLine()?.Trim();
                if (!string.IsNullOrEmpty(path) && Directory.Exists(path))
                {
                    return path;
                }
                Console.WriteLine("Ошибка: Папка не существует или путь неверный.");
            }
            return null;
        }

        private void SendFolderPath(string folderPath, string pipeName)
        {
            try
            {
                using (var pipeServer = new NamedPipeServerStream(pipeName, PipeDirection.Out))
                {
                    Console.WriteLine($"Master: Waiting for Scanner to connect on control pipe {pipeName}...");
                    pipeServer.WaitForConnection();
                    using (var writer = new StreamWriter(pipeServer) { AutoFlush = true })
                    {
                        writer.WriteLine(folderPath);
                        Console.WriteLine($"Master: Sent folder path to {pipeName}: {folderPath}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Master Control Pipe {pipeName} Error: {ex.Message}");
            }
        }

        private void HandlePipe(string pipeName)
        {
            try
            {
                using (var pipeServer = new NamedPipeServerStream(pipeName, PipeDirection.In))
                {
                    Console.WriteLine($"Master: Waiting for connection on data pipe {pipeName}...");
                    pipeServer.WaitForConnection();
                    Console.WriteLine($"Master: Connected to {pipeName}");
                    using (var reader = new StreamReader(pipeServer))
                    {
                        while (!reader.EndOfStream)
                        {
                            string line = reader.ReadLine();
                            if (!string.IsNullOrEmpty(line))
                            {
                                var parts = line.Split(':');
                                if (parts.Length == 3 && int.TryParse(parts[2], out int count))
                                {
                                    string fileName = parts[0];
                                    string word = parts[1];

                                    lock (lockObject)
                                    {
                                        if (!aggregatedIndex.ContainsKey(fileName))
                                            aggregatedIndex[fileName] = new Dictionary<string, int>();
                                        aggregatedIndex[fileName][word] = aggregatedIndex[fileName].GetValueOrDefault(word, 0) + count;
                                    }
                                    Console.WriteLine($"Master: Processed {line}");
                                }
                                else
                                {
                                    Console.WriteLine($"Invalid data format: {line}");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error handling pipe {pipeName}: {ex.Message}");
            }
        }

        private void DisplayResults()
        {
            try
            {
                while (!Task.WhenAll(Task.Delay(Timeout.Infinite)).IsCompleted)
                {
                    lock (lockObject)
                    {
                        Console.Clear();
                        Console.WriteLine($"Агрегированный индекс слов (Обновлено: {DateTime.Now:HH:mm:ss}):");
                        foreach (var fileEntry in aggregatedIndex.OrderBy(x => x.Key))

                        {
                            foreach (var wordEntry in fileEntry.Value.OrderBy(x => x.Key))
                            {
                                Console.WriteLine($"{fileEntry.Key}:{wordEntry.Key}:{wordEntry.Value}");
                            }
                        }
                    }
                    Thread.Sleep(2000); // Refresh every 2 seconds
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error displaying results: {ex.Message}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var master = new Master();
            master.Start();
        }
    }
}