﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Master
{
    class Master
    {
        private readonly string[] dataPipeNames = { "agent1", "agent2" };
        private readonly string[] controlPipeNames = { "control1", "control2" };
        private readonly Dictionary<string, Dictionary<string, int>> aggregatedIndex = new();
        private readonly object lockObject = new();
        private CancellationTokenSource displayCts = new CancellationTokenSource();

        // Starts the Master process
        public void Start()
        {
            // Set CPU core affinity to core 2
            Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(4); // Core 2

            // Prompt user to choose scanning mode
            bool useSingleFolder = ChooseScanningMode();
            string pathsForScannerA, pathsForScannerB;

            if (useSingleFolder)
            {
                // Prompt for a single folder and split files
                (pathsForScannerA, pathsForScannerB) = SelectSingleFolderAndSplitFiles();
                if (string.IsNullOrEmpty(pathsForScannerA) && string.IsNullOrEmpty(pathsForScannerB))
                {
                    Console.WriteLine("Invalid folder or no .txt files found. Exiting.");
                    Console.WriteLine("Press Enter to exit...");
                    Console.ReadLine();
                    return;
                }
                Console.WriteLine($"Selected folder for both Scanners with split files:");
                Console.WriteLine($"ScannerA files: {pathsForScannerA}");
                Console.WriteLine($"ScannerB files: {pathsForScannerB}");
            }
            else
            {
                // Prompt for two folder paths
                (string folderPathA, string folderPathB) = SelectFolderPaths();
                if (string.IsNullOrEmpty(folderPathA) || string.IsNullOrEmpty(folderPathB))
                {
                    Console.WriteLine("Invalid or missing folder paths. Exiting.");
                    Console.WriteLine("Press Enter to exit...");
                    Console.ReadLine();
                    return;
                }
                pathsForScannerA = folderPathA;
                pathsForScannerB = folderPathB;
                Console.WriteLine($"Selected folder for ScannerA: {folderPathA}");
                Console.WriteLine($"Selected folder for ScannerB: {folderPathB}");
            }

            try
            {
                // Start tasks to send paths to Scanners
                Task[] controlTasks = new Task[controlPipeNames.Length];
                controlTasks[0] = Task.Run(() => SendPaths(pathsForScannerA, controlPipeNames[0])); // ScannerA
                controlTasks[1] = Task.Run(() => SendPaths(pathsForScannerB, controlPipeNames[1])); // ScannerB

                // Start tasks to listen for data from Scanners
                Task[] dataTasks = new Task[dataPipeNames.Length];
                for (int i = 0; i < dataPipeNames.Length; i++)
                {
                    string pipeName = dataPipeNames[i];
                    dataTasks[i] = Task.Run(() => HandlePipe(pipeName));
                }

                // Start task to display results
                Task displayTask = Task.Run(() => DisplayResults(displayCts.Token));

                // Wait for control tasks to complete
                bool controlTasksCompleted = Task.WaitAll(controlTasks, 15000); // Timeout after 15 seconds
                if (!controlTasksCompleted)
                {
                    Console.WriteLine("Timeout waiting for paths to be sent to scanners.");
                }

                // Wait for data tasks to complete with a timeout
                bool dataTasksCompleted = Task.WaitAll(dataTasks, 90000); // 90 seconds timeout
                if (!dataTasksCompleted)
                {
                    Console.WriteLine("Timeout waiting for data from scanners.");
                }

                // Stop display task
                displayCts.Cancel();
                displayTask.Wait(2000); // Allow one last refresh

                // Check if no data was received
                lock (lockObject)
                {
                    if (aggregatedIndex.Count == 0)
                    {
                        Console.WriteLine("\nNo data received. Check if .txt files contain valid words or if Scanners are running correctly.");
                    }
                }

                Console.WriteLine("\nProcessing complete. Press Enter to exit...");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Master error: {ex.Message}");
                displayCts.Cancel();
                Console.WriteLine("Press Enter to exit...");
                Console.ReadLine();
            }
        }

        // Prompts user to choose between one or two folders
        private bool ChooseScanningMode()
        {
            int maxAttempts = 3;
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                Console.WriteLine($"Choose scanning mode (attempt {attempt}/{maxAttempts}):");
                Console.WriteLine("1. Scan one folder (split files between Scanners)");
                Console.WriteLine("2. Scan two folders (different for each Scanner)");
                Console.Write("Enter 1 or 2: ");
                string input = Console.ReadLine()?.Trim();
                if (input == "1")
                {
                    return true; // Single folder
                }
                else if (input == "2")
                {
                    return false; // Two folders
                }
                else
                {
                    Console.WriteLine("Error: Enter 1 or 2.");
                }
            }
            Console.WriteLine("Too many invalid attempts. Defaulting to one folder.");
            return true; // Default to single folder
        }

        // Prompts for a single folder and splits .txt files
        private (string, string) SelectSingleFolderAndSplitFiles()
        {
            int maxAttempts = 3;
            string folderPath = null;

            // Prompt for folder path
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                Console.WriteLine($"Enter path for both Scanners with .txt files (e.g., C:\\TestFolder) (attempt {attempt}/{maxAttempts}):");
                string path = Console.ReadLine()?.Trim('"', ' ').Trim(); // Fixed: Use 'path' instead of redefining 'folderPath'
                if (!string.IsNullOrEmpty(path))
                {
                    if (Directory.Exists(path))
                    {
                        folderPath = path;
                        break;
                    }
                    else if (File.Exists(path))
                    {
                        Console.WriteLine("Error: Specified a file path, not a folder. Enter a folder path.");
                    }
                    else
                    {
                        Console.WriteLine("Error: Folder does not exist or path is invalid.");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Path not entered.");
                }
            }

            if (string.IsNullOrEmpty(folderPath))
            {
                return (null, null);
            }

            // Get .txt files and split them
            try
            {
                var txtFiles = Directory.GetFiles(folderPath, "*.txt").ToList();
                if (txtFiles.Count == 0)
                {
                    Console.WriteLine("No .txt files found in the folder.");
                    return (null, null);
                }

                // Split files: even indices to ScannerA, odd to ScannerB
                var filesForScannerA = txtFiles.Where((_, i) => i % 2 == 0).ToList(); // Fixed: Use txtFiles
                var filesForScannerB = txtFiles.Where((_, i) => i % 2 != 0).ToList(); // Fixed: Use txtFiles

                // Convert to semicolon-separated strings
                string pathsForScannerA = filesForScannerA.Any() ? string.Join(";", filesForScannerA) : "";
                string pathsForScannerB = filesForScannerB.Any() ? string.Join(";", filesForScannerB) : "";

                return (pathsForScannerA, pathsForScannerB);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error accessing files in folder: {ex.Message}");
                return (null, null); // Fixed: Correct return type
            }
        }

        // Prompts user to enter two folder paths
        private (string, string) SelectFolderPaths()
        {
            int maxAttempts = 3;
            string folderPathA = null; // Fixed: Removed invalid ", null"
            string folderPathB = null;

            // Prompt for ScannerA path
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                Console.WriteLine($"Enter path for ScannerA with .txt files (e.g., C:\\FolderA) (attempt {attempt}/{maxAttempts}):");
                string path = Console.ReadLine()?.Trim('"', ' ').Trim();
                if (!string.IsNullOrEmpty(path))
                {
                    if (Directory.Exists(path))
                    {
                        folderPathA = path;
                        break;
                    }
                    else if (File.Exists(path))
                    {
                        Console.WriteLine("Error: Specified a file path, not a folder. Enter a folder path.");
                    }
                    else
                    {
                        Console.WriteLine("Error: Folder does not exist or path is invalid.");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Path not entered.");
                }
            }

            // Prompt for ScannerB path
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                Console.WriteLine($"Enter path for ScannerB with .txt files (e.g., C:\\FolderB) (attempt {attempt}/{maxAttempts}):");
                string path = Console.ReadLine()?.Trim('"', ' ').Trim();
                if (!string.IsNullOrEmpty(path))
                {
                    if (Directory.Exists(path))
                    {
                        folderPathB = path;
                        break;
                    }
                    else if (File.Exists(path))
                    {
                        Console.WriteLine("Error: Specified a file path, not a folder. Enter a folder path.");
                    }
                    else
                    {
                        Console.WriteLine("Error: Folder does not exist or path is invalid.");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Path not entered.");
                }
            }

            return (folderPathA, folderPathB);
        }

        // Sends paths (folder or file list) to a Scanner via control pipe
        private void SendPaths(string paths, string pipeName)
        {
            try
            {
                using (var pipeServer = new NamedPipeServerStream(pipeName, PipeDirection.Out))
                {
                    Console.WriteLine($"Master: Waiting for Scanner to connect to control pipe {pipeName}...");
                    pipeServer.WaitForConnection();
                    using (var writer = new StreamWriter(pipeServer) { AutoFlush = true })
                    {
                        writer.WriteLine(paths);
                        Console.WriteLine($"Master: Sent paths to {pipeName}: {paths}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Master Control Pipe {pipeName} error: {ex.Message}");
            }
        }

        // Handles data received from Scanners via data pipe
        private void HandlePipe(string pipeName)
        {
            try
            {
                using (var pipeServer = new NamedPipeServerStream(pipeName, PipeDirection.In))
                {
                    Console.WriteLine($"Master: Waiting for connection to data pipe {pipeName}...");
                    pipeServer.WaitForConnection();
                    Console.WriteLine($"Master: Connected to {pipeName}");
                    using (var reader = new StreamReader(pipeServer))
                    {
                        while (!reader.EndOfStream)
                        {
                            string line = reader.ReadLine()?.Trim();
                            if (!string.IsNullOrEmpty(line))
                            {
                                Console.WriteLine($"Master: Received line: {line}");
                                var parts = line.Split(':');
                                if (parts.Length == 3 && int.TryParse(parts[2], out int count))
                                {
                                    string fileName = parts[0];
                                    string word = parts[1];
                                    lock (lockObject)
                                    {
                                        if (!aggregatedIndex.ContainsKey(fileName))
                                            aggregatedIndex[fileName] = new Dictionary<string, int>();
                                        aggregatedIndex[fileName][word] = aggregatedIndex[fileName].GetValueOrDefault(word, 0) + count;
                                    }
                                    Console.WriteLine($"Master: Processed: {line}");
                                }
                                else
                                {
                                    Console.WriteLine($"Master: Invalid data format: {line}");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Master: Error handling pipe {pipeName}: {ex.Message}");
            }
        }

        // Displays aggregated word index periodically
        private void DisplayResults(CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    lock (lockObject)
                    {
                        Console.Clear();
                        Console.WriteLine($"Aggregated Word Index (Updated: {DateTime.Now:HH:mm:ss}):");
                        if (aggregatedIndex.Count == 0)
                        {
                            Console.WriteLine("No data received yet...");
                        }
                        foreach (var fileEntry in aggregatedIndex.OrderBy(x => x.Key))
                        {
                            foreach (var wordEntry in fileEntry.Value.OrderBy(x => x.Key))
                            {
                                Console.WriteLine($"{fileEntry.Key}:{wordEntry.Key}:{wordEntry.Value}");
                            }
                        }
                    }
                    Thread.Sleep(2000); // Refresh every 2 seconds
                }
            }
            catch (OperationCanceledException)
            {
                // Expected when token is cancelled
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Master: Error displaying results: {ex.Message}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var master = new Master();
            master.Start();
        }
    }
}